import WalletType from "./WalletType";

export type { WalletType };
