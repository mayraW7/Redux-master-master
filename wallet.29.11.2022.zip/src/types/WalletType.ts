interface WalletType {
  balance: number;
  income: number[];
  outcome: number[];
}

export default WalletType;
