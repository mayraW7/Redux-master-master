import { combineReducers } from "@reduxjs/toolkit";

import wallet from "./WalletSlice";

export default combineReducers({
  wallet,
});
