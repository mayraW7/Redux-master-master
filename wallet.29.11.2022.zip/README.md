# List Contacts - Redux Toolkit

Aplication developed for example to use Redux Toolkit.

## Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm run dev`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Screenshots

### Desktop

![image](https://github.com/marcelo-growdev/list-contacts-redux-tollkit/blob/master/public/images/screenshots/login.png)

![image](https://github.com/marcelo-growdev/list-contacts-redux-tollkit/blob/master/public/images/screenshots/app-desktop.png)

### Mobile

![image](https://github.com/marcelo-growdev/list-contacts-redux-tollkit/blob/master/public/images/screenshots/app-mobile.png)
